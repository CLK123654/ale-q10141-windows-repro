# 实验归因复核材料

database目录保存脱敏实验事件库。rules/attribution_policy.json给出报告区间、污染裁决和转化窗口，rules/report_layout.csv规定三张业务报表的字段与排序。

把完成SQL保存为output/rebuild_ab_attribution.sql。在input_data目录使用PowerShell7执行tools/run-task.ps1。脚本复制源库，调用SQLite载入策略、执行交付SQL并导出报表。正式处理只访问本地文件。
