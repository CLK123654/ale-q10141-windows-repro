param(
  [string]$SqlitePath = $env:SQLITE3_PATH
)

$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$sourceDb = Join-Path $root 'database/ab_experiment.db'
$policyPath = Join-Path $root 'rules/attribution_policy.json'
$layoutPath = Join-Path $root 'rules/report_layout.csv'
$outputRoot = Join-Path $root 'output'
$reportsRoot = Join-Path $outputRoot 'reports'
$solutionSql = Join-Path $outputRoot 'rebuild_ab_attribution.sql'
$outputDb = Join-Path $outputRoot 'ab_attribution_review.db'

function Remove-DerivedOutput {
  Remove-Item -LiteralPath $outputDb -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $reportsRoot -Recurse -Force -ErrorAction SilentlyContinue
  Get-ChildItem -LiteralPath $outputRoot -Filter '.driver-*.sql' -ErrorAction SilentlyContinue | Remove-Item -Force
}

function Escape-SqlText([string]$Value) {
  return $Value.Replace("'", "''")
}

try {
  foreach ($required in @($sourceDb, $policyPath, $layoutPath, $solutionSql)) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
      throw "缺少输入文件：$required"
    }
  }

  if ([string]::IsNullOrWhiteSpace($SqlitePath)) {
    $SqlitePath = (Get-Command sqlite3 -ErrorAction Stop).Source
  }
  if (-not (Test-Path -LiteralPath $SqlitePath -PathType Leaf)) {
    throw "找不到SQLite命令行：$SqlitePath"
  }

  $policyText = Get-Content -LiteralPath $policyPath -Raw -Encoding utf8
  $policy = $policyText | ConvertFrom-Json
  $policyJson = [System.Text.Json.JsonDocument]::Parse($policyText)
  $reportStartUtc = $policyJson.RootElement.GetProperty('report_start_utc').GetString()
  $reportEndUtc = $policyJson.RootElement.GetProperty('report_end_utc').GetString()
  $layouts = @(Import-Csv -LiteralPath $layoutPath -Encoding utf8)
  if ($policy.conversion_window_hours -le 0 -or [DateTimeOffset]::Parse($reportStartUtc) -ge [DateTimeOffset]::Parse($reportEndUtc)) {
    throw '归因策略的时间范围或窗口无效'
  }
  if ($layouts.Count -ne 3 -or ($layouts.report_file | Select-Object -Unique).Count -ne 3) {
    throw '报表布局需要三个唯一文件'
  }
  foreach ($layout in $layouts) {
    foreach ($field in @('report_file', 'source_table', 'columns', 'order_by')) {
      if ([string]::IsNullOrWhiteSpace($layout.$field)) { throw "报表布局缺少字段：$field" }
    }
    if ($layout.report_file -notmatch '^[a-z0-9_]+\.csv$' -or $layout.source_table -notmatch '^[a-z_]+$') {
      throw "报表布局包含非法对象：$($layout.report_file)"
    }
  }

  New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null
  Remove-DerivedOutput
  Copy-Item -LiteralPath $sourceDb -Destination $outputDb

  $driverPath = Join-Path $outputRoot ('.driver-' + [guid]::NewGuid().ToString('N') + '.sql')
  $solutionForSqlite = $solutionSql.Replace('\', '/')
  $driver = @(
    '.bail on',
    'PRAGMA foreign_keys=ON;',
    'CREATE TEMP TABLE task_contract(key TEXT PRIMARY KEY, value TEXT NOT NULL);',
    "INSERT INTO temp.task_contract VALUES('report_start_utc','$(Escape-SqlText $reportStartUtc)');",
    "INSERT INTO temp.task_contract VALUES('report_end_utc','$(Escape-SqlText $reportEndUtc)');",
    "INSERT INTO temp.task_contract VALUES('conversion_window_hours','$(Escape-SqlText ([string]$policy.conversion_window_hours))');",
    ".read `"$solutionForSqlite`""
  )
  Set-Content -LiteralPath $driverPath -Value $driver -Encoding utf8NoBOM
  & $SqlitePath $outputDb ".read `"$($driverPath.Replace('\', '/'))`""
  if ($LASTEXITCODE -ne 0) { throw "SQLite执行失败，退出码$LASTEXITCODE" }

  New-Item -ItemType Directory -Path $reportsRoot -Force | Out-Null
  foreach ($layout in $layouts) {
    $columns = ($layout.columns -split '\|') -join ','
    $orderBy = ($layout.order_by -split '\|') -join ','
    if ($columns -notmatch '^[a-z0-9_,]+$' -or $orderBy -notmatch '^[a-z0-9_,]+$') {
      throw "报表字段包含非法标识符：$($layout.report_file)"
    }
    $query = "SELECT $columns FROM $($layout.source_table) ORDER BY $orderBy;"
    $target = Join-Path $reportsRoot $layout.report_file
    $rows = & $SqlitePath -header -csv $outputDb $query
    if ($LASTEXITCODE -ne 0) { throw "报表导出失败：$($layout.report_file)" }
    Set-Content -LiteralPath $target -Value $rows -Encoding utf8NoBOM
  }

  Remove-Item -LiteralPath $driverPath -Force
  Write-Host "实验归因报表已生成：$outputRoot"
} catch {
  Remove-DerivedOutput
  Write-Error $_
  exit 2
}
