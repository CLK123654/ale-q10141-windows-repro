BEGIN IMMEDIATE;

DROP TABLE IF EXISTS valid_exposure;
DROP TABLE IF EXISTS sample_contamination;
DROP TABLE IF EXISTS attribution_window;
DROP TABLE IF EXISTS cohort_metrics;
DROP TABLE IF EXISTS report_meta;

CREATE TABLE sample_contamination(
  source_id TEXT PRIMARY KEY,
  source_table TEXT NOT NULL,
  user_id TEXT NOT NULL,
  experiment_id TEXT NOT NULL,
  reason TEXT NOT NULL,
  detail TEXT NOT NULL
);

WITH assignment_family AS (
  SELECT a.user_id, e.family_key, COUNT(DISTINCT a.experiment_id) AS experiment_count
  FROM assignment_event AS a
  JOIN experiment_catalog AS e ON e.experiment_id=a.experiment_id
  GROUP BY a.user_id,e.family_key
),
ranked_exposure AS (
  SELECT x.*,
    ROW_NUMBER() OVER(
      PARTITION BY x.user_id,x.experiment_id,x.session_id
      ORDER BY datetime(x.exposed_at_utc),x.exposure_id
    ) AS duplicate_rank,
    FIRST_VALUE(x.exposure_id) OVER(
      PARTITION BY x.user_id,x.experiment_id,x.session_id
      ORDER BY datetime(x.exposed_at_utc),x.exposure_id
    ) AS kept_exposure_id
  FROM exposure_event AS x
),
context AS (
  SELECT x.*,e.family_key,e.metric_name,e.active_from_utc,e.active_to_utc,
    u.user_status,u.is_bot,COALESCE(f.experiment_count,0) AS family_experiment_count,
    (SELECT value FROM temp.task_contract WHERE key='report_start_utc') AS report_start_utc,
    (SELECT value FROM temp.task_contract WHERE key='report_end_utc') AS report_end_utc
  FROM ranked_exposure AS x
  JOIN experiment_catalog AS e ON e.experiment_id=x.experiment_id
  JOIN user_dimension AS u ON u.user_id=x.user_id
  LEFT JOIN assignment_family AS f ON f.user_id=x.user_id AND f.family_key=e.family_key
),
candidate_reason AS (
  SELECT context.*,'mutual_family_conflict' AS reason FROM context WHERE family_experiment_count>1
  UNION ALL
  SELECT context.*,'duplicate_exposure' FROM context WHERE duplicate_rank>1
  UNION ALL
  SELECT context.*,'user_disabled' FROM context WHERE user_status<>'active'
  UNION ALL
  SELECT context.*,'bot_user' FROM context WHERE is_bot<>0
  UNION ALL
  SELECT context.*,'outside_experiment_window' FROM context
  WHERE datetime(exposed_at_utc)<datetime(active_from_utc)
     OR datetime(exposed_at_utc)>=datetime(active_to_utc)
     OR datetime(exposed_at_utc)<datetime(report_start_utc)
     OR datetime(exposed_at_utc)>=datetime(report_end_utc)
),
reasoned AS (
  SELECT candidate_reason.*,
    ROW_NUMBER() OVER(PARTITION BY exposure_id ORDER BY priority) AS reason_rank
  FROM candidate_reason
  JOIN temp.task_reason_priority USING(reason)
)
INSERT INTO sample_contamination(source_id,source_table,user_id,experiment_id,reason,detail)
SELECT exposure_id,'exposure_event',user_id,experiment_id,reason,
  CASE reason
    WHEN 'mutual_family_conflict' THEN 'family='||family_key||';experiment_count='||family_experiment_count
    WHEN 'duplicate_exposure' THEN 'duplicate_rank='||duplicate_rank||';kept_exposure_id='||kept_exposure_id
    WHEN 'user_disabled' THEN 'user_status='||user_status
    WHEN 'bot_user' THEN 'is_bot='||is_bot
    WHEN 'outside_experiment_window' THEN 'exposed_at_utc outside report or experiment active window'
  END
FROM reasoned
WHERE reason_rank=1
ORDER BY exposure_id;

CREATE TABLE valid_exposure(
  exposure_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  experiment_id TEXT NOT NULL,
  variant TEXT NOT NULL,
  session_id TEXT NOT NULL,
  exposed_at_utc TEXT NOT NULL,
  family_key TEXT NOT NULL,
  metric_name TEXT NOT NULL
);

INSERT INTO valid_exposure
SELECT x.exposure_id,x.user_id,x.experiment_id,x.variant,x.session_id,x.exposed_at_utc,e.family_key,e.metric_name
FROM exposure_event AS x
JOIN experiment_catalog AS e ON e.experiment_id=x.experiment_id
LEFT JOIN sample_contamination AS c ON c.source_id=x.exposure_id
WHERE c.source_id IS NULL
ORDER BY x.exposure_id;

CREATE TABLE attribution_window(
  conversion_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  matched_exposure_id TEXT,
  experiment_id TEXT,
  variant TEXT,
  attribution_status TEXT NOT NULL,
  latency_minutes INTEGER,
  value_cents INTEGER NOT NULL
);

WITH valid_candidate AS (
  SELECT c.conversion_id,v.exposure_id,v.experiment_id,v.variant,
    CAST(ROUND((julianday(c.occurred_at_utc)-julianday(v.exposed_at_utc))*1440) AS INTEGER) AS latency_minutes,
    ROW_NUMBER() OVER(PARTITION BY c.conversion_id ORDER BY datetime(v.exposed_at_utc) DESC,v.exposure_id DESC) AS candidate_rank
  FROM conversion_event AS c
  JOIN valid_exposure AS v ON v.user_id=c.user_id AND v.metric_name=c.conversion_type
  WHERE datetime(c.occurred_at_utc)>=datetime(v.exposed_at_utc)
),
contaminated_candidate AS (
  SELECT c.conversion_id,x.exposure_id,x.experiment_id,x.variant,
    CAST(ROUND((julianday(c.occurred_at_utc)-julianday(x.exposed_at_utc))*1440) AS INTEGER) AS latency_minutes,
    ROW_NUMBER() OVER(PARTITION BY c.conversion_id ORDER BY datetime(x.exposed_at_utc) DESC,x.exposure_id DESC) AS candidate_rank
  FROM conversion_event AS c
  JOIN exposure_event AS x ON x.user_id=c.user_id
  JOIN experiment_catalog AS e ON e.experiment_id=x.experiment_id AND e.metric_name=c.conversion_type
  JOIN sample_contamination AS s ON s.source_id=x.exposure_id AND s.reason='mutual_family_conflict'
  WHERE datetime(c.occurred_at_utc)>=datetime(x.exposed_at_utc)
),
chosen AS (
  SELECT c.conversion_id,c.user_id,c.value_cents,
    v.exposure_id AS valid_exposure_id,v.experiment_id AS valid_experiment_id,v.variant AS valid_variant,v.latency_minutes AS valid_latency,
    m.exposure_id AS contaminated_exposure_id,m.experiment_id AS contaminated_experiment_id,m.variant AS contaminated_variant,m.latency_minutes AS contaminated_latency,
    CAST((SELECT value FROM temp.task_contract WHERE key='conversion_window_hours') AS INTEGER) AS window_hours
  FROM conversion_event AS c
  LEFT JOIN valid_candidate AS v ON v.conversion_id=c.conversion_id AND v.candidate_rank=1
  LEFT JOIN contaminated_candidate AS m ON m.conversion_id=c.conversion_id AND m.candidate_rank=1
)
INSERT INTO attribution_window(conversion_id,user_id,matched_exposure_id,experiment_id,variant,attribution_status,latency_minutes,value_cents)
SELECT conversion_id,user_id,
  CASE WHEN contaminated_exposure_id IS NOT NULL THEN NULL ELSE valid_exposure_id END,
  COALESCE(contaminated_experiment_id,valid_experiment_id),
  COALESCE(contaminated_variant,valid_variant),
  CASE
    WHEN contaminated_exposure_id IS NOT NULL THEN 'blocked_by_contamination'
    WHEN valid_exposure_id IS NULL THEN 'no_prior_exposure'
    WHEN valid_latency>window_hours*60 THEN 'outside_'||window_hours||'h_window'
    ELSE 'attributed'
  END,
  COALESCE(contaminated_latency,valid_latency),value_cents
FROM chosen
ORDER BY conversion_id;

CREATE TABLE cohort_metrics(
  experiment_id TEXT NOT NULL,
  variant TEXT NOT NULL,
  valid_exposures INTEGER NOT NULL,
  attributed_conversions INTEGER NOT NULL,
  revenue_cents INTEGER NOT NULL,
  conversion_rate_pct TEXT NOT NULL,
  PRIMARY KEY(experiment_id,variant)
);

INSERT INTO cohort_metrics
SELECT v.experiment_id,v.variant,COUNT(DISTINCT v.exposure_id) AS valid_exposures,
  SUM(CASE WHEN a.attribution_status='attributed' THEN 1 ELSE 0 END) AS attributed_conversions,
  SUM(CASE WHEN a.attribution_status='attributed' THEN a.value_cents ELSE 0 END) AS revenue_cents,
  printf('%.2f',100.0*SUM(CASE WHEN a.attribution_status='attributed' THEN 1 ELSE 0 END)/COUNT(DISTINCT v.exposure_id))
FROM valid_exposure AS v
LEFT JOIN attribution_window AS a ON a.matched_exposure_id=v.exposure_id
GROUP BY v.experiment_id,v.variant
ORDER BY v.experiment_id,v.variant;

CREATE TABLE report_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT INTO report_meta VALUES
  ('report_start_utc',(SELECT value FROM temp.task_contract WHERE key='report_start_utc')),
  ('report_end_utc',(SELECT value FROM temp.task_contract WHERE key='report_end_utc')),
  ('conversion_window_hours',(SELECT value FROM temp.task_contract WHERE key='conversion_window_hours'));

COMMIT;
